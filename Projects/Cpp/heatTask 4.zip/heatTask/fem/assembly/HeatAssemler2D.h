#pragma once 


class HeatAssembler2D {
    public:
    private:

};