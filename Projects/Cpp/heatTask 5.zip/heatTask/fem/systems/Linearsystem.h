#pragma once
#include <Eigen/Dense>

struct LinearSystem {
    Eigen::MatrixXd glob_K;
    Eigen::MatrixXd glob_F;
};