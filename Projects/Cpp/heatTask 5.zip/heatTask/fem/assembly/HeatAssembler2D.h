#pragma once
#include <Eigen/Dense>

#include "../../HeatProblem/HeatProblem.h"
#include "../../Mesh/Mesh2D.h"
#include "../systems/Linearsystem.h"

class HeatAssembler2D {
  private:
    HeatProblem &problem_;
    Mesh &mesh_;

    Eigen::Matrix<double, 3, 3> locK_;
    Eigen::Vector3d locF_;

    Eigen::MatrixXd globK_;
    Eigen::VectorXd globF_;

  public:
    HeatAssembler2D(const HeatProblem &problem, const Mesh &mesh);
    LinearSystem Assemble();

  private:
    void MakeLocalF(const TriangleP1& triangle);
    void MakeLocalK(const TriangleP1& triangle);
    void AddToGlobal(std::size_t elId);
};