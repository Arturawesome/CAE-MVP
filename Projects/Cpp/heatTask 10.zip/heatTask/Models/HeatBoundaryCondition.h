#pragma once
#include "BoundaryId.h"
enum class HeatBoundaryCondition { Dirichlet, Neumann, Robin };


struct BoundaryCondition {
    BoundaryId boundaryId = 0;
    HeatBoundaryCondition type;

    double value1 = 0;
    double value2 = 0;
};