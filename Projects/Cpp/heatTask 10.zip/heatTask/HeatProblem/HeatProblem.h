#pragma once
#include <functional>
#include <iostream>
#include <vector>

#include "../Models/HeatBoundaryCondition.h"
#include "../Mesh/Mesh2D.h"

class HeatProblem {
  private:
    const Mesh &mesh_;
    double lambda_;

  private:
    std::function<double(double, double, double)> source_;
    std::vector<BoundaryCondition> boundaryConditions_;
    bool meshHasBoundaryMarker(int marker);

  public:
    HeatProblem(const Mesh &mesh, double lambda,
                std::function<double(double, double, double)> source);
    ~HeatProblem() = default;

    // Getters
    const Mesh &GetMesh() const;
    double Lambda() const;
    double Source(double x, double y, double z = 0.0) const;
    double Source(const Point2D& elementCenter) const;
    const std::vector<BoundaryCondition>& BoundaryConditions() const;

    void AddDirichlet(BoundaryId id, double temprature);
    void AddNeumann(BoundaryId id, double flux);
    void AddRobin(BoundaryId id, double alpha, double temprature);

    // TO DO template for GUI (in futher)
    void AddDirichlet(std::vector<int> edgeIds, double temprature);
    void AddNeumann(std::vector<int> edgeIds, double flux);
    void AddRobin(std::vector<int> edgeIds, double alpha, double temprature);

};




















