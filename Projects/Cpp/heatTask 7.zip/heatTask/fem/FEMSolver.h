#pragma once

#include "../HeatProblem/HeatProblem.h"
#include "../Mesh/Mesh2D.h"
#include "systems/LinearSystem.h"
#include <Eigen/Dense>
#include <array>
#include <iostream>
#include <string>
#include <vector>

class FEMSolver {
  private:
    const HeatProblem &problem;
    const Mesh &mesh;
    Eigen::VectorXd solution;



  private:
   
    void addBoundCondToGlobalMat(LinearSystem &system);

    void addDirichletToGlobalMatrix(LinearSystem &system, int marker,
                                    double value);
    void applyDirichletToNode(LinearSystem &system, int nodeId, double value);

    void addNeumannToGlobalMatrix(LinearSystem &system, int marker,
                                  double flux);
    void applyNeumannToEdge(LinearSystem &system, const BoundaryEdge &be,
                            double flux);

    void addRobinToGlobalMatrix(LinearSystem &system, int marker, double value1,
                                double value2);

  public:
    FEMSolver(HeatProblem &problem_);
    ~FEMSolver() = default;
    void Solve();
    Eigen::VectorXd &Solution();
};