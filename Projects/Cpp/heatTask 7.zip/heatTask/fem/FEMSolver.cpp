#include "FEMSolver.h"
#include "../BoundaryCondition/BoundaryConditions.h"
#include "elements/TriangleP1.h"
#include "assembly/HeatAssembler2D.h"

#include <cmath>
#include <fstream>
#include <stdexcept>
#include <unordered_set>
#include <utility>


FEMSolver::FEMSolver(HeatProblem &problem_)
    : problem(problem_), mesh(problem_.GetMesh()) {

    std::cout << "FEMSolver::FEMSolver\n";
    int numNodes = mesh.NumNodes();
    solution = Eigen::VectorXd::Zero(numNodes);
}

void FEMSolver::Solve() {

    HeatAssembler2D assembler(problem, mesh);
    LinearSystem system = assembler.Assemble();
    addBoundCondToGlobalMat(system);
    solution = system.K.partialPivLu().solve(system.F);

    if (!solution.allFinite()) {
        throw std::runtime_error("FEMSolver: solution Contains NaN or Inf");
    }
    
}


void FEMSolver::addBoundCondToGlobalMat(LinearSystem &system){
    int numBC = problem.BC_size();
    for (int i = 0; i < numBC; ++i) {
        BoundaryType type = problem.GetTypeBC(i);
        int marker = problem.GetMarkerBC(i);
        double value1 = problem.GetValue1BC(i);
        double value2 = problem.GetValue2BC(i);
        switch (type) {
        case BoundaryType::Neumann:
            addNeumannToGlobalMatrix(system, marker, value1);
            break;
        case BoundaryType::Robin:
            addRobinToGlobalMatrix(system, marker, value1, value2);
            break;
        case BoundaryType::Dirichlet:
            addDirichletToGlobalMatrix(system, marker, value1);
            break;
        }
    }
    
}

void FEMSolver::addRobinToGlobalMatrix(LinearSystem &system, int marker, double value1,
                                       double value2) {
    std::cout<< system.K.size() << marker << value1 << value2 << "\n";
}

void FEMSolver::addNeumannToGlobalMatrix(LinearSystem &system, int marker, double flux) {
    std::size_t processedEdges = 0;

    for (const BoundaryEdge &be : mesh.BoundaryEdges()) {
        if (be.boundaryId != marker) {
            continue;
        }
        applyNeumannToEdge(system, be, flux);
        ++processedEdges;
    }
    if (processedEdges == 0) {
        throw std::runtime_error("FEMSolver: no boundary edges with marker " +
                                 std::to_string(marker));
    }

    return;
}

void FEMSolver::applyNeumannToEdge(LinearSystem &system, const BoundaryEdge &be, double flux) {
    int id1 = be.nodes_id.first;
    int id2 = be.nodes_id.second;

    const Node &node1 = mesh.NodeById(id1);
    const Node &node2 = mesh.NodeById(id2);

    double dx = node2.position.x - node1.position.x;
    double dy = node2.position.y - node1.position.y;

    const double edgeLength = std::hypot(dx, dy);
    if (edgeLength <= 0.0) {
        throw std::runtime_error(
            "FEMSolver::applyNeumannToEdge: zero-length boundary edge");
    }

    double localContribution = flux * 0.5 * edgeLength;

    
    system.F[id1] += localContribution;
    system.F[id2] += localContribution;
}

void FEMSolver::addDirichletToGlobalMatrix(LinearSystem &system, int marker, double value) {
    std::unordered_set<int> nodes;
    for (const BoundaryEdge &be : mesh.BoundaryEdges()) {
        if (be.boundaryId != marker) {
            continue;
        }
        nodes.insert(be.nodes_id.first);
        nodes.insert(be.nodes_id.second);
    }
    if (nodes.empty()) {
        throw std::runtime_error("FEMSolver: no boundary edges with marker " +
                                 std::to_string(marker));
    }
    for (const int nodeId : nodes) {
        applyDirichletToNode(system, nodeId, value);
    }
}

void FEMSolver::applyDirichletToNode(LinearSystem &system, int nodeId, double value) {
    const Eigen::Index s = static_cast<Eigen::Index>(nodeId);
    if (s < 0 || s >= system.K.rows()) {
        throw std::out_of_range("FEMSolver: invalid Dirichlet node index");
    }

    system.F -= system.K.col(s) * value;

    system.K.row(s).setZero();
    system.K.col(s).setZero();

    system.K(s, s) = 1.0;
    system.F(s) = value;
}


Eigen::VectorXd& FEMSolver::Solution(){
    return solution;
}

