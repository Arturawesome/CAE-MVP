#include "HeatProblem.h"

HeatProblem::HeatProblem(const Mesh &mesh, double lambda,
                         std::function<double(double, double, double)> source)
    : mesh_(mesh), lambda_(lambda), source_(source) {
    std::cout << "HeatProblem::HeatProblem\n";
    if (lambda_ <= 0) {
        throw std::invalid_argument("HeatProblem: lambda must be positive\n");
    }
}

double HeatProblem::Lambda() const { return lambda_; }

double HeatProblem::Source(double x, double y, double z) const {
    return source_(x, y, z);
}
double HeatProblem::Source(const Point2D &elementCenter) const {
    return source_(elementCenter.x, elementCenter.y, 0);
}

const Mesh &HeatProblem::Mesh() const { return mesh_; }

void HeatProblem::AddBoundaryCondition(const BoundaryCondition &condition) {
    if (hasBoundaryCondition(condition.marker)) {
        throw std::invalid_argument(
            "HeatProblem: boundary condition already exists");
    }
    boundaryConditions_.push_back(condition);
}

const std::vector<BoundaryCondition> &HeatProblem::BoundaryConditions() const {
    return boundaryConditions_;
}

bool HeatProblem::hasBoundaryCondition(int marker) const {
    for (const BoundaryCondition &bc : boundaryConditions_) {
        if (bc.marker == marker)
            return true;
    }
    return false;
}

bool HeatProblem::meshHasBoundaryMarker(int marker) {
    return mesh_.HasBoundaryMarker(marker);
}




// int HeatProblem::BC_size() const { return boundaryConditions_.size(); }

// BoundaryType HeatProblem::GetTypeBC(int i) const {
//     return boundaryConditions_[i].type;
// }

// int HeatProblem::GetMarkerBC(int i) const {
//     return boundaryConditions_[i].marker;
// }

// double HeatProblem::GetValue1BC(int i) const {
//     return boundaryConditions_[i].value1;
// }
// double HeatProblem::GetValue2BC(int i) const {
//     return boundaryConditions_[i].value2;
// }
