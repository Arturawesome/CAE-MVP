#pragma once
#include <functional>
#include <iostream>
#include <vector>

#include "../BoundaryCondition/BoundaryConditions.h"
#include "../Mesh/Mesh2D.h"

class HeatProblem {
  private:
    const Mesh &mesh_;
    double lambda_;

  private:
    std::function<double(double, double, double)> source_;
    std::vector<BoundaryCondition> boundaryConditions_;
    bool meshHasBoundaryMarker(int marker);

  public:
    HeatProblem(const Mesh &mesh, double lambda,
                std::function<double(double, double, double)> source);
    ~HeatProblem() = default;

    // Getters
    const Mesh &Mesh() const;

    double Lambda() const;
    double Source(double x, double y, double z = 0.0) const;
    double Source(const Point2D& elementCenter) const;
    const std::vector<BoundaryCondition>& BoundaryConditions() const;

    void AddBoundaryCondition(const BoundaryCondition &condition);
    
    bool hasBoundaryCondition(int marker) const;
    // int BC_size() const;
    
    // BoundaryType GetTypeBC(int i) const;
    // int GetMarkerBC(int i) const;
    // double GetValue1BC(int i) const;
    // double GetValue2BC(int i) const;
};